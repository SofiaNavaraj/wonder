package er.ajaxjq.components;

import java.net.MalformedURLException;

import com.webobjects.appserver.WOActionResults;
import com.webobjects.appserver.WOAssociation;
import com.webobjects.appserver.WOComponent;
import com.webobjects.appserver.WOContext;
import com.webobjects.appserver.WOElement;
import com.webobjects.appserver.WORequest;
import com.webobjects.appserver.WOResponse;
import com.webobjects.foundation.NSDictionary;
import com.webobjects.foundation.NSForwardException;
import com.webobjects.foundation.NSMutableDictionary;

import er.ajax.AjaxDynamicElement;
import er.ajax.AjaxUtils;
import er.ajaxjq.utils.AjaxJQUtils;
import er.extensions.appserver.ERXRequest;
import er.extensions.appserver.ajax.ERXAjaxApplication;
import er.extensions.components.ERXComponentUtilities;
import er.extensions.foundation.ERXMutableURL;

public class AjaxJQPeriodicUpdate extends AjaxDynamicElement {

	public AjaxJQPeriodicUpdate(String name, NSDictionary associations, WOElement children) {
		super(name, associations, children);
	}

	@Override
	protected void addRequiredWebResources(WOResponse response, WOContext context) {
		addScriptResourceInHead(context, response, "AjaxJQ", "jquery.js");
		addScriptResourceInHead(context, response, "AjaxJQ", "jquery.livequery.js");
		addScriptResourceInHead(context, response, "AjaxJQ", "wonderjq.js");
	}
	
	@Override
	public void appendToResponse(WOResponse response, WOContext context) {
		WOComponent component = context.component();
		
		String elementName = (String) valueForBinding("elementName", "span", component);

		response.appendContentString("<");
		response.appendContentString(elementName);
		response.appendContentString(" ");
		appendTagAttributeToResponse(response, "class", AjaxJQUtils.cssClassForElementAndComponent(this, component));
		appendTagAttributeToResponse(response, "style", valueForBinding("style", component));
		appendTagAttributeToResponse(response, "id", valueForBinding("id", component));

		String json = AjaxJQUtils.simpleSerialize(_options(context));
		appendTagAttributeToResponse(response, "data-wo", json);
			
		response.appendContentString(">");
		appendChildrenToResponse(response, context);
		response.appendContentString("</");
		response.appendContentString(elementName);
		response.appendContentString(">");
		super.appendToResponse(response, context);
	}
	
	// Generate the options dictionary for the update element
	private NSDictionary<String, Object> _options(WOContext context) {
		NSMutableDictionary<String, Object> woData = new NSMutableDictionary<String, Object>();
		WOComponent component = context.component();
		String actionUrl = null;
		WOAssociation directActionNameAssociation = (WOAssociation) associations().valueForKey("directActionName");
		WOAssociation actionNameAssociation = (WOAssociation) associations().valueForKey("action");
		String replaceId = (String)valueForBinding("replaceID", component);
		
		if ( directActionNameAssociation != null ) {
			actionUrl = context._directActionURL((String) directActionNameAssociation.valueInComponent(component), ERXComponentUtilities.queryParametersInComponent(associations(), component), ERXRequest.isRequestSecure(context.request())).replaceAll("&amp;", "&");
		} else if ( actionNameAssociation != null && replaceId != null ) {
			actionUrl = AjaxUtils.ajaxComponentActionUrl(context);
		}
		
		boolean async = booleanValueForBinding("asynchronous", true, component);
		if ( !async ) { 
			woData.takeValueForKey(String.valueOf(async), "async");
		}
		
		String updateId = (String)valueForBinding("updateContainerID", component);
		if (updateId != null) {
			woData.takeValueForKey(updateId, "updateid");
			if ( directActionNameAssociation != null ) {
				woData.takeValueForKey(actionUrl, "actionurl");
			} else if ( actionNameAssociation != null ){
				String elementID = context.contextID() + "." + context.elementID();
				woData.takeValueForKey(elementID, "elementid");
			}
		}
		
		String period = (String)valueForBinding("period", component);
		if (period != null) {
			woData.takeValueForKey(period, "period");
		}
		
		if (replaceId != null && actionUrl != null) {
			woData.takeValueForKey(replaceId, "replaceid");
			try {
				ERXMutableURL tempActionUrl = new ERXMutableURL(actionUrl);
				tempActionUrl.addQueryParameter(ERXAjaxApplication.KEY_REPLACED, "true");
				actionUrl = tempActionUrl.toExternalForm();
			} catch (MalformedURLException e) {
				throw NSForwardException._runtimeExceptionForThrowable(e);
			}
			woData.takeValueForKey(actionUrl, "actionurl");
		}
		boolean stopped = booleanValueForBinding("stopped", false, component);
		if (stopped) {
			woData.takeValueForKey("true", "stopped");
		}
		String jsDelegateName = (String)valueForBinding("delegate", component);
		woData.takeValueForKey(jsDelegateName, "delegate");
		return woData;
	}

	@Override
	public WOActionResults handleRequest(WORequest request, WOContext context) {
		WOComponent component = context.component();
		String updateContainerID = AjaxJQUpdateContainer.updateContainerID(this, component); 
		AjaxJQUpdateContainer.setUpdateContainerID(request, updateContainerID);
		WOActionResults results = (WOActionResults) valueForBinding("action", component);

		if (ERXAjaxApplication.isAjaxReplacement(request)) {
			AjaxUtils.setPageReplacementCacheKey(context, (String)valueForBinding("replaceID", component));
		}
		else if (results == null || booleanValueForBinding("ignoreActionResponse", false, component)) {
			String script = (String) valueForBinding("onClickServer", component);
			if (script != null) {
				WOResponse response = AjaxUtils.createResponse(request, context);
				AjaxUtils.appendScriptHeaderIfNecessary(request, response);
				response.appendContentString(script);
				AjaxUtils.appendScriptFooterIfNecessary(request, response);
				results = response;
			}
		}
		else if (updateContainerID != null) {
			AjaxUtils.setPageReplacementCacheKey(context, updateContainerID);
		}

		return results;
	}

}