package er.ajaxjq.components;

import java.net.MalformedURLException;

import com.webobjects.appserver.WOActionResults;
import com.webobjects.appserver.WOAssociation;
import com.webobjects.appserver.WOComponent;
import com.webobjects.appserver.WOContext;
import com.webobjects.appserver.WOElement;
import com.webobjects.appserver.WORequest;
import com.webobjects.appserver.WOResponse;
import com.webobjects.foundation.NSDictionary;
import com.webobjects.foundation.NSForwardException;
import com.webobjects.foundation.NSMutableDictionary;

import er.ajax.AjaxDynamicElement;
import er.ajax.AjaxUtils;
import er.ajaxjq.utils.AjaxJQUtils;
import er.extensions.appserver.ERXRequest;
import er.extensions.appserver.ajax.ERXAjaxApplication;
import er.extensions.components.ERXComponentUtilities;
import er.extensions.foundation.ERXMutableURL;

public class AjaxJQUpdateLink extends AjaxDynamicElement {

	public AjaxJQUpdateLink(String name, NSDictionary associations, WOElement children) {
		super(name, associations, children);
	}

	@Override
	protected void addRequiredWebResources(WOResponse response, WOContext context) {
		addScriptResourceInHead(context, response, "AjaxJQ", "jquery.js");
		addScriptResourceInHead(context, response, "AjaxJQ", "jquery.livequery.js");
		addScriptResourceInHead(context, response, "AjaxJQ", "wonderjq.js");
	}

	@Override
	public void appendToResponse(WOResponse response, WOContext context) {
		WOComponent component = context.component();

		boolean disabled = booleanValueForBinding("disabled", false, component);
		Object stringValue = valueForBinding("string", component);
		String elementName;
		boolean button = booleanValueForBinding("button", false, component);
		if (button) {
			elementName = "input";
		}
		else {
			elementName = (String) valueForBinding("elementName", "a", component);
		}
		boolean isATag = "a".equalsIgnoreCase(elementName);
		boolean renderTags = (!disabled || !isATag);
		if (renderTags) {
			response.appendContentString("<");
			response.appendContentString(elementName);
			response.appendContentString(" ");
			if (button) {
				appendTagAttributeToResponse(response, "type", "button");
			}

			appendTagAttributeToResponse(response, "title", valueForBinding("title", component));
			appendTagAttributeToResponse(response, "value", valueForBinding("value", component));
			appendTagAttributeToResponse(response, "class", AjaxJQUtils.cssClassForElementAndComponent(this, component));
			appendTagAttributeToResponse(response, "style", valueForBinding("style", component));
			appendTagAttributeToResponse(response, "id", valueForBinding("id", component));
			appendTagAttributeToResponse(response, "accesskey", valueForBinding("accesskey", component));
			
			WOAssociation directActionNameAssociation = (WOAssociation) associations().valueForKey("directActionName");
			String actionUrl = null, localUrl = null;
			String replaceId = (String)valueForBinding("replaceID", component);
			boolean isDA = directActionNameAssociation != null;
			if ( isDA ) {
				localUrl = context._directActionURL((String) directActionNameAssociation.valueInComponent(component), ERXComponentUtilities.queryParametersInComponent(associations(), component), ERXRequest.isRequestSecure(context.request())).replaceAll("&amp;", "&");
				actionUrl = localUrl;
			} else {
				actionUrl = AjaxUtils.ajaxComponentActionUrl(context);
				localUrl = context.componentActionURL();
			}
			
			if (isATag) {
				if (localUrl != null) {
					appendTagAttributeToResponse(response, "href", localUrl);
				} else {
					appendTagAttributeToResponse(response, "href", "#");
				}
			}
			
			String json = AjaxJQUtils.simpleSerialize(_options(context, actionUrl, isDA, replaceId));
			appendTagAttributeToResponse(response, "data-wo", json);
			
			if (button) {
				if (stringValue != null) {
					appendTagAttributeToResponse(response, "value", stringValue);
				}
				if (disabled) {
					response.appendContentString(" disabled");
				}
			}
			response.appendContentString(">");
		}
		if (stringValue != null && !button) {
			response.appendContentHTMLString(stringValue.toString());
		}
		appendChildrenToResponse(response, context);
		if (renderTags) {
			response.appendContentString("</");
			response.appendContentString(elementName);
			response.appendContentString(">");
		}
		super.appendToResponse(response, context);
	}
	
	// Generate the options dictionary for the update element
	private NSDictionary<String, Object> _options(WOContext context, String actionUrl, boolean isDA, String replaceId) {
		//WOAssociation directActionNameAssociation = (WOAssociation) associations().valueForKey("directActionName");
		WOComponent component = context.component();
		
		NSMutableDictionary<String, Object> woData = new NSMutableDictionary<String, Object>();
		boolean async = booleanValueForBinding("asynchronous", true, component);
		if ( !async ) { 
			woData.takeValueForKey(String.valueOf(async), "async");
		}
		String updateId = AjaxJQUpdateContainer.updateContainerID(this, component);
		
		if (replaceId != null) {
			woData.takeValueForKey(replaceId, "replaceid");
			try {
				ERXMutableURL tempActionUrl = new ERXMutableURL(actionUrl);
				tempActionUrl.addQueryParameter(ERXAjaxApplication.KEY_REPLACED, "true");
				actionUrl = tempActionUrl.toExternalForm();
			} catch (MalformedURLException e) {
				throw NSForwardException._runtimeExceptionForThrowable(e);
			}
			woData.takeValueForKey(actionUrl, "actionurl");
		} else {
			woData.takeValueForKey(updateId, "updateid");
			if ( isDA ) {
				woData.takeValueForKey(actionUrl, "actionurl");
			} else {
				String elementID = context.contextID() + "." + context.elementID();
				woData.takeValueForKey(elementID, "elementid");
			}
		}
		
		String jsDelegateName = (String)valueForBinding("delegate", component);
		woData.takeValueForKey(jsDelegateName, "delegate");
		return woData;
	}

	@Override
	public WOActionResults handleRequest(WORequest request, WOContext context) {
		WOComponent component = context.component();
		String updateContainerID = AjaxJQUpdateContainer.updateContainerID(this, component); 
		AjaxJQUpdateContainer.setUpdateContainerID(request, updateContainerID);
		WOActionResults results = (WOActionResults) valueForBinding("action", component);

		if (ERXAjaxApplication.isAjaxReplacement(request)) {
			AjaxUtils.setPageReplacementCacheKey(context, (String)valueForBinding("replaceID", component));
		}
		else if (results == null || booleanValueForBinding("ignoreActionResponse", false, component)) {
			String script = (String) valueForBinding("onClickServer", component);
			if (script != null) {
				WOResponse response = AjaxUtils.createResponse(request, context);
				AjaxUtils.appendScriptHeaderIfNecessary(request, response);
				response.appendContentString(script);
				AjaxUtils.appendScriptFooterIfNecessary(request, response);
				results = response;
			}
		}
		else if (updateContainerID != null) {
			AjaxUtils.setPageReplacementCacheKey(context, updateContainerID);
		}

		return results;
	}

}