package er.ajaxjq.components;

import com.webobjects.appserver.WOActionResults;
import com.webobjects.appserver.WOComponent;
import com.webobjects.appserver.WOContext;
import com.webobjects.appserver.WOElement;
import com.webobjects.appserver.WORequest;
import com.webobjects.appserver.WOResponse;
import com.webobjects.foundation.NSDictionary;
import com.webobjects.foundation.NSLog;
import com.webobjects.foundation.NSMutableDictionary;

import er.ajax.AjaxDynamicElement;
import er.ajax.AjaxUtils;
import er.ajaxjq.utils.AjaxJQUtils;
import er.extensions.appserver.ERXWOContext;
import er.extensions.appserver.ajax.ERXAjaxApplication;

public class AjaxJQUpdateContainer extends AjaxDynamicElement {

	private static final String CURRENT_UPDATE_CONTAINER_ID_KEY = "er.ajax.AjaxJQUpdateContainer.currentID";

	public AjaxJQUpdateContainer(String name, NSDictionary associations, WOElement children) {
		super(name, associations, children);
	}

	@Override
	protected void addRequiredWebResources(WOResponse response, WOContext context) {
		addScriptResourceInHead(context, response, "AjaxJQ", "jquery.js");
		addScriptResourceInHead(context, response, "AjaxJQ", "jquery.livequery.js");
		addScriptResourceInHead(context, response, "AjaxJQ", "wonderjq.js");
	}

	@Override
	public WOActionResults handleRequest(WORequest request, WOContext context) {
		//NSLog.out.appendln("AjaxJQUpdateContainer.handleRequest: " + request);
		WOComponent component = context.component();
		String id = _containerID(context);

		if (associations().objectForKey("action") != null) {
			@SuppressWarnings("unused")
			WOActionResults results = (WOActionResults) valueForBinding("action", component);
			// ignore results
		}

		WOResponse response = AjaxUtils.createResponse(request, context);
		AjaxUtils.setPageReplacementCacheKey(context, id);
		if (hasChildrenElements()) {
			appendChildrenToResponse(response, context);
		}
//		String onRefreshComplete = (String) valueForBinding("onRefreshComplete", component);
//		if (onRefreshComplete != null) {
//			AjaxUtils.appendScriptHeader(response);
//			response.appendContentString(onRefreshComplete);
//			AjaxUtils.appendScriptFooter(response);
//		}
//		if (AjaxModalDialog.isInDialog(context)) {
//			AjaxUtils.appendScriptHeader(response);
//			response.appendContentString("AMD.contentUpdated();");
//			AjaxUtils.appendScriptFooter(response);
//		}
		return null;
	}

	@Override
	public void appendToResponse(WOResponse response, WOContext context) {
		WOComponent component = context.component();
		//		if (!shouldRenderContainer(component)) {
		//			if (hasChildrenElements()) {
		//				appendChildrenToResponse(response, context);
		//			}
		//			super.appendToResponse(response, context);
		//		}
		//		else {
		String previousUpdateContainerID = AjaxJQUpdateContainer.currentUpdateContainerID();
		try {
			String elementName = (String) valueForBinding("elementName", "div", component);
			String id = _containerID(context);
			NSLog.out.appendln("AjaxJQUpdateContainer.appendToResponse: " + id);
			AjaxJQUpdateContainer.setCurrentUpdateContainerID(id);
			
			response.appendContentString("<" + elementName + " ");
			appendTagAttributeToResponse(response, "id", id);
			appendTagAttributeToResponse(response, "class", AjaxJQUtils.cssClassForElementAndComponent(this, component));
			//appendTagAttributeToResponse(response, "class", valueForBinding("class", component));
			appendTagAttributeToResponse(response, "style", valueForBinding("style", component));
			
			appendTagAttributeToResponse(response, "data-wo", AjaxJQUtils.simpleSerialize(_options(context)));
			// appendTagAttributeToResponse(response, "woElementID", context.elementID());
			response.appendContentString(">");
			if (hasChildrenElements()) {
				appendChildrenToResponse(response, context);
			}
			response.appendContentString("</" + elementName + ">");

			super.appendToResponse(response, context);
		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			AjaxJQUpdateContainer.setCurrentUpdateContainerID(previousUpdateContainerID);
		}
	}
	
	protected NSDictionary<String, Object> _options(WOContext context) {
		WOComponent component = context.component();
		NSMutableDictionary<String, Object> _options = new NSMutableDictionary<String, Object>();
		_options.takeValueForKey(AjaxUtils.ajaxComponentActionUrl(context), "updateurl");
		String period = (String)valueForBinding("period", component);
		if (period != null) {
			_options.takeValueForKey(period, "period");
		}
		boolean stopped = booleanValueForBinding("stopped", false, component);
		if (stopped) {
			_options.takeValueForKey("true", "stopped");
		}
		String delegateName = (String)valueForBinding("delegate", component);
		if (delegateName != null) {
			_options.takeValueForKey(delegateName, "delegate");
		}
		return _options;
	}

	@Override
	protected String _containerID(WOContext context) {
		String id = (String) valueForBinding("id", context.component());
		if (id == null) {
			id = ERXWOContext.safeIdentifierName(context, false);
		}
		return id;
	}
	
	// UPDATE CONTAINTER IDs
	
	public static String updateContainerID(WORequest request) {
		NSDictionary userInfo = AjaxUtils.mutableUserInfo(request);
		String updateContainerID = (String) userInfo.objectForKey(ERXAjaxApplication.KEY_UPDATE_CONTAINER_ID);
		return updateContainerID;
	}

	public static void setUpdateContainerID(WORequest request, String updateContainerID) {
		if (updateContainerID != null) {
			AjaxUtils.mutableUserInfo(request).setObjectForKey(updateContainerID, ERXAjaxApplication.KEY_UPDATE_CONTAINER_ID);
		}
	}

	public static boolean hasUpdateContainerID(WORequest request) {
		return AjaxJQUpdateContainer.updateContainerID(request) != null;
	}

	public static String currentUpdateContainerID() {
		return (String) ERXWOContext.contextDictionary().objectForKey(AjaxJQUpdateContainer.CURRENT_UPDATE_CONTAINER_ID_KEY);
	}

	public static void setCurrentUpdateContainerID(String updateContainerID) {
		if (updateContainerID == null) {
			ERXWOContext.contextDictionary().removeObjectForKey(AjaxJQUpdateContainer.CURRENT_UPDATE_CONTAINER_ID_KEY);
		}
		else {
			ERXWOContext.contextDictionary().setObjectForKey(updateContainerID, AjaxJQUpdateContainer.CURRENT_UPDATE_CONTAINER_ID_KEY);
		}
	}

	protected static String updateContainerID(AjaxDynamicElement element, WOComponent component) {
		return AjaxJQUpdateContainer.updateContainerID(element, "updateContainerID", component);
	}

	protected static String updateContainerID(AjaxDynamicElement element, String bindingName, WOComponent component) {
		String updateContainerID = (String) element.valueForBinding("updateContainerID", component);
		//NSLog.out.appendln("AjaxJQUpdateContainer.updateContainerID: " + updateContainerID + " - " + element);
		return AjaxJQUpdateContainer.updateContainerID(updateContainerID);
	}

	protected static String updateContainerID(String updateContainerID) {
		if ("_parent".equals(updateContainerID)) {
			updateContainerID = AjaxJQUpdateContainer.currentUpdateContainerID();
		}
		return updateContainerID;
	}
	


}