package er.ajaxjq.components;

import java.net.MalformedURLException;

import com.webobjects.appserver.WOActionResults;
import com.webobjects.appserver.WOAssociation;
import com.webobjects.appserver.WOComponent;
import com.webobjects.appserver.WOContext;
import com.webobjects.appserver.WOElement;
import com.webobjects.appserver.WORequest;
import com.webobjects.appserver.WOResponse;
import com.webobjects.appserver._private.WODynamicElementCreationException;
import com.webobjects.foundation.NSDictionary;
import com.webobjects.foundation.NSForwardException;
import com.webobjects.foundation.NSMutableDictionary;

import er.ajax.AjaxDynamicElement;
import er.ajax.AjaxUtils;
import er.ajaxjq.utils.AjaxJQUtils;
import er.extensions.appserver.ERXRequest;
import er.extensions.appserver.ajax.ERXAjaxApplication;
import er.extensions.components.ERXComponentUtilities;
import er.extensions.components._private.ERXWOForm;
import er.extensions.foundation.ERXMutableURL;
import er.extensions.foundation.ERXProperties;

public class AjaxJQSubmit extends AjaxDynamicElement {
	// MS: If you change this value, make sure to change it in ERXAjaxApplication
  public static final String KEY_AJAX_SUBMIT_BUTTON_NAME = "AJAX_SUBMIT_BUTTON_NAME";
	// MS: If you change this value, make sure to change it in ERXAjaxApplication and in wonder.js
  public static final String KEY_PARTIAL_FORM_SENDER_ID = "_partialSenderID";
  
	public AjaxJQSubmit(String name, NSDictionary associations, WOElement children) {
		super(name, associations, children);
	}

	@Override
	protected void addRequiredWebResources(WOResponse response, WOContext context) {
		addScriptResourceInHead(context, response, "AjaxJQ", "jquery.js");
		addScriptResourceInHead(context, response, "AjaxJQ", "jquery.livequery.js");
		addScriptResourceInHead(context, response, "AjaxJQ", "wonderjq.js");
	}

	@Override
	public void appendToResponse(WOResponse response, WOContext context) {
		WOComponent component = context.component();
		String functionName = (String)valueForBinding("functionName", null, component);
		String formName = (String)valueForBinding("formName", component);
		boolean showUI = (functionName == null || booleanValueForBinding("showUI", false, component));
		boolean showButton = showUI && booleanValueForBinding("button", true, component);
		String formReference;
		if ((!showButton || functionName != null) && formName == null) {
			formName = ERXWOForm.formName(context, null);
			if (formName == null) {
				throw new WODynamicElementCreationException("If button = false or functionName is not null, the containing form must have an explicit name.");
			}
		}
		if (formName == null) {
			formReference = "this.form";
		} else {
			formReference = "document." + formName;
		}

		if ( showUI ) {
			boolean disabled = disabledInComponent(component);
			String elementName = (String) valueForBinding("elementName", "a", component);
			boolean useButtonTag = ERXProperties.booleanForKeyWithDefault("er.extensions.foundation.ERXPatcher.DynamicElementsPatches.SubmitButton.useButtonTag", false);
			
			if ( showButton ) {
				elementName = useButtonTag ? "button" : "input";
				response.appendContentString("<" + elementName + " ");
				appendTagAttributeToResponse(response, "type", "button");
				String name = nameInContext(context, component);
				appendTagAttributeToResponse(response, "name", name);
				appendTagAttributeToResponse(response, "value", valueForBinding("value", component));
				appendTagAttributeToResponse(response, "accesskey", valueForBinding("accesskey", component));
				if (disabled) {
					appendTagAttributeToResponse(response, "disabled", "disabled");
				}
			} else {
				boolean isATag = "a".equalsIgnoreCase(elementName);
				if (isATag) {
					response.appendContentString("<a href = \"javascript:void(0)\" ");
				} else {
					response.appendContentString("<" + elementName + " ");
				}
			}
			appendTagAttributeToResponse(response, "class", AjaxJQUtils.cssClassForElementAndComponent(this, component));
			appendTagAttributeToResponse(response, "style", valueForBinding("style", component));
			appendTagAttributeToResponse(response, "id", valueForBinding("id", component));
			appendTagAttributeToResponse(response, "title", valueForBinding("title", component));
			appendTagAttributeToResponse(response, "data-wo", AjaxJQUtils.simpleSerialize(_options(context)));
			if (showButton && !useButtonTag) {
				response.appendContentString(" />");
			} else {
				response.appendContentString(">");
				if (hasChildrenElements()) {
					appendChildrenToResponse(response, context);
				} else {
					response.appendContentString((String)valueForBinding("value", component));
				}
				response.appendContentString("</" + elementName + ">");
			}
			super.appendToResponse(response, context);
		}
	}
	
	private NSDictionary<String, Object> _options(WOContext context) {
		
		WOComponent component = context.component();
		String actionUrl = null;
		WOAssociation directActionNameAssociation = (WOAssociation) associations().valueForKey("directActionName");
		String replaceId = (String)valueForBinding("replaceID", component);
		
		if ( directActionNameAssociation != null ) {
			actionUrl = context._directActionURL((String) directActionNameAssociation.valueInComponent(component), ERXComponentUtilities.queryParametersInComponent(associations(), component), ERXRequest.isRequestSecure(context.request())).replaceAll("&amp;", "&");
		} else if ( replaceId != null ) {
			actionUrl = AjaxUtils.ajaxComponentActionUrl(context);
		}
		
		NSMutableDictionary<String, Object> woData = new NSMutableDictionary<String, Object>();
		boolean async = booleanValueForBinding("asynchronous", true, component);
		if ( !async ) { 
			woData.takeValueForKey(String.valueOf(async), "async");
		}
		String updateId = AjaxJQUpdateContainer.updateContainerID(this, component);
		
		if (replaceId != null) {
			woData.takeValueForKey(replaceId, "replaceid");
			try {
				ERXMutableURL tempActionUrl = new ERXMutableURL(actionUrl);
				tempActionUrl.addQueryParameter(ERXAjaxApplication.KEY_REPLACED, "true");
				actionUrl = tempActionUrl.toExternalForm();
			} catch (MalformedURLException e) {
				throw NSForwardException._runtimeExceptionForThrowable(e);
			}
			woData.takeValueForKey(actionUrl, "actionurl");
		} else {
			woData.takeValueForKey(updateId, "updateid");
			if ( directActionNameAssociation != null ) {
				woData.takeValueForKey(actionUrl, "actionurl");
			} else {
				String elementID = context.contextID() + "." + context.elementID();
				woData.takeValueForKey(elementID, "elementid");
			}
		}
		
		woData.takeValueForKey(nameInContext(component.context(), component), "_asbn"); // cleaned element id
		woData.takeValueForKey(valueForBinding("formName", component), "form"); // form name
		woData.takeValueForKey(valueForBinding("delegate", component), "delegate"); // js behaviour delegate name
		return woData;
	}
	
	@Override
  public WOActionResults invokeAction(WORequest worequest, WOContext wocontext) {
    WOActionResults result = null;
    WOComponent wocomponent = wocontext.component();

    String nameInContext = nameInContext(wocontext, wocomponent);
    boolean shouldHandleRequest = (!disabledInComponent(wocomponent) && wocontext._wasFormSubmitted()) && ((wocontext._isMultipleSubmitForm() && nameInContext.equals(worequest.formValueForKey(KEY_AJAX_SUBMIT_BUTTON_NAME))) || !wocontext._isMultipleSubmitForm());
    if (shouldHandleRequest) {
    	String updateContainerID = AjaxJQUpdateContainer.updateContainerID(this, wocomponent);
      AjaxJQUpdateContainer.setUpdateContainerID(worequest, updateContainerID);
      wocontext._setActionInvoked(true);
      result = handleRequest(worequest, wocontext);
      AjaxUtils.updateMutableUserInfoWithAjaxInfo(wocontext);
    }
    
    return result;
  }
  
	@Override
  public WOActionResults handleRequest(WORequest request, WOContext context) {
	   WOComponent component = context.component();
	   WOActionResults result = (WOActionResults) valueForBinding("action", component);

	   if (ERXAjaxApplication.isAjaxReplacement(request)) {
		   AjaxUtils.setPageReplacementCacheKey(context, (String)valueForBinding("replaceID", component));
	   }
	   else if (result == null || booleanValueForBinding("ignoreActionResponse", false, component)) {
	     WOResponse response = AjaxUtils.createResponse(request, context);
	     String onClickServer = (String) valueForBinding("onClickServer", component);
	     if (onClickServer != null) {
	       AjaxUtils.appendScriptHeaderIfNecessary(request, response);
	       response.appendContentString(onClickServer);
	       AjaxUtils.appendScriptFooterIfNecessary(request, response);
	     }
	     result = response;
	   }
	   else {
		   String updateContainerID = AjaxJQUpdateContainer.updateContainerID(this, component);
		   if (updateContainerID != null) {
			   AjaxUtils.setPageReplacementCacheKey(context, updateContainerID);
		   }
	   }
	   return result;
	 }
	
  public String nameInContext(WOContext context, WOComponent component) {
    return (String) valueForBinding("name", context.elementID(), component);
  }
  
  public static boolean isAjaxSubmit(WORequest request) {
	  return request.formValueForKey(KEY_AJAX_SUBMIT_BUTTON_NAME) != null;
  }
  
  public boolean disabledInComponent(WOComponent component) {
    return booleanValueForBinding("disabled", false, component);
  }


}