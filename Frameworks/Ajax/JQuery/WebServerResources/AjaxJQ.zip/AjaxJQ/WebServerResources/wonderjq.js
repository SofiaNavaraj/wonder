/**
 * jquery.dump.js
 * @author Torkild Dyvik Olsen
 * @version 1.0
 * 
 * A simple debug function to gather information about an object.
 * Returns a nested tree with information.
 * 
 */
(function(h){h.fn.dump=function(){return h.dump(this)};h.dump=function(b){var c=function(n,d){if(!d){d=0}var o="",p="";for(i=0;i<d;i++){p+="  "}t=a(n);switch(t){case"string":return'"'+n+'"';break;case"number":return n.toString();break;case"boolean":return n?"true":"false";case"date":return"Date: "+n.toLocaleString();case"array":o+="Array ( \n";h.each(n,function(j,k){o+=p+"  "+j+" => "+c(k,d+1)+"\n"});o+=p+")";break;case"object":o+="Object { \n";h.each(n,function(j,k){o+=p+"  "+j+": "+c(k,d+1)+"\n"});o+=p+"}";break;case"jquery":o+="jQuery Object { \n";h.each(n,function(j,k){o+=p+"  "+j+" = "+c(k,d+1)+"\n"});o+=p+"}";break;case"regexp":return"RegExp: "+n.toString();case"error":return n.toString();case"document":case"domelement":o+="DOMElement [ \n"+p+"  nodeName: "+n.nodeName+"\n"+p+"  nodeValue: "+n.nodeValue+"\n"+p+"  innerHTML: [ \n";h.each(n.childNodes,function(k,l){if(k<1){var j=0}if(a(l)=="string"){if(l.textContent.match(/[^\s]/)){o+=p+"    "+(k-(j||0))+" = String: "+f(l.textContent)+"\n"}else{j--}}else{o+=p+"    "+(k-(j||0))+" = "+c(l,d+2)+"\n"}});o+=p+"  ]\n"+p+"]";break;case"function":var q=n.toString().match(/^(.*)\(([^\)]*)\)/im);q[1]=f(q[1].replace(new RegExp("[\\s]+","g")," "));q[2]=f(q[2].replace(new RegExp("[\\s]+","g")," "));return q[1]+"("+q[2]+")";case"window":default:o+="N/A: "+t;break}return o};var a=function(d){var k=typeof(d);if(k!="object"){return k}switch(d){case null:return"null";case window:return"window";case document:return"document";case window.event:return"event";default:break}if(d.jquery){return"jquery"}switch(d.constructor){case Array:return"array";case Boolean:return"boolean";case Date:return"date";case Object:return"object";case RegExp:return"regexp";case ReferenceError:case Error:return"error";case null:default:break}switch(d.nodeType){case 1:return"domelement";case 3:return"string";case null:default:break}return"Unknown"};return c(b)};function f(a){return g(e(a))}function g(a){return a.replace(new RegExp("^[\\s]+","g"),"")}function e(a){return a.replace(new RegExp("[\\s]+$","g"),"")}})(jQuery);

/**
 * WOjax.jq 
 * @author David LeBer
 * @version 0.1
 * 
 * WebObjects Ajax framework based on jQuery, designed with 
 * unobtrusive js principles in mind.
 */
var $j = jQuery.noConflict();

var WOjax = WOjax || {};
WOjax.namespace = function (ns) {
    var parts = ns.split('.'),
        parent = WOjax,
        i;

    if (parts[0] === 'WOjax') {
        parts = parts.slice(1);
    }

    for (i = 0; i < parts.length; i += 1) {
        if (typeof parent[parts[i]] === "undefined") {
            console.log("creating: " + parts[i]);
            parent[parts[i]] = {};
        }
        parent = parent[parts[i]];
    }
    return parent;
};

WOjax.namespace('jq');
WOjax.namespace('jq.Delegates');
WOjax.namespace('jq.StringUtil');
WOjax.namespace('jq.UpdateLink');
WOjax.namespace('jq.Submit');
WOjax.namespace('jq.Observe');
WOjax.namespace('jq.PeriodicUpdate');
WOjax.namespace('jq.UpdateContainer');

/**
 * Identifies a element that will trigger an ajax update of another element on the page.
 * 
 */
WOjax.jq.UpdateLink = {

    register: function () {
        var self = WOjax.jq.UpdateLink;
        $j('.AjaxJQUpdateLink').livequery('click', function (event) {
            var caller = this;
            
            event.preventDefault();
            self.handleClick(caller);
        });
        console.log('registered UpdateLink');
    },
    performClick: function(elementId, parameters) {
        var self = WOjax.jq.UpdateLink,
            $caller = $j(elementId);

        console.log('performClick: ' + elementId + ' - ' + $j.dump($caller));
        self.handleClick($caller, parameters);
    },
    handleClick: function(caller, parameters) {
        var self = WOjax.jq.UpdateLink,
            Delegates = WOjax.jq.Delegates,
            $caller = $j(caller),
            options = $caller.data('wo'),
            ucid = '',
            $target = {};

        $caller.data('params', parameters);
        $caller.data('isUpdate', true);
        console.log('options: ' + $j.dump($caller) + ' - ' + $j.dump(options));
        if (options.updateid !== undefined) {
            ucid = '#' + options.updateid;
        } else if (options.replaceid !== undefined) {
            ucid = '#' + options.replaceid;
            $caller.data('isUpdate', false);
        } else {
            // if the caller has neither an updateid or replaceid
            // then lets assume it is updating itself (i.e: a uc with
            // a periodic update)
            ucid = '#' + $caller.attr('id')
        }
        console.log(ucid);
        $target = $j(ucid);
        if (Delegates[options.delegate] !== undefined && Delegates[options.delegate].before !== undefined) {
            console.log('has before delegate');
            Delegates[options.delegate].before($caller, $target, self.performUpdate);
        } else {
            self.performUpdate($caller, $target);
        }
    },
    performUpdate: function(caller, target) {
        var self = WOjax.jq.UpdateLink,
            Delegates = WOjax.jq.Delegates,
            $caller = $j(caller),
            $target = $j(target),
            options = $caller.data('wo'),
            isUpdate = $caller.data('isUpdate'),
            isAsync = true,
            params = $caller.data('params'),
            url = '',
            ucOptions = $target.data('wo');
        
        if (isUpdate) {
            url = ucOptions.updateurl;
            if (options.elementid !== undefined) {
                url = url.replace(/[^\/]+$/, options.elementid);
            }
        } else {
            url = options.actionurl;
        }
        if (options.async !== undefined) {
            isAsync = options.async === 'true';
        }
        if (params !== undefined) {
            url = WOjax.jq.StringUtil.addQueryParameters(url, params);
        }
        console.log(url);
        $j.ajax({
            url: url,
            //type: type,
            async: isAsync,
            //data: data,
            //beforeSend: function (jqXHR, settings){}, //TODO
            success: function(responseData, textStatus, jqXH) {
                if (isUpdate) {
                    $target.html(responseData);
                } else {
                    $target.replaceWith(responseData);
                }
                if (Delegates[options.delegate] !== undefined && Delegates[options.delegate].success !== undefined) {
                    Delegates[options.delegate].success($caller, $target, self.handleFinish);
                } else {
                    self.handleFinish($caller, $target);
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                options.errorThrown = errorThrown;
                options.textStatus = textStatus;
                if (Delegates[options.delegate] !== undefined && Delegates[options.delegate].error !== undefined) {
                    Delegates[options.delegate].error($caller, $target, self.handleFinish);
                } else {
                    self.handleFinish($caller, $target);
                }
            }
        });
    },
    handleFinish: function(caller, target) {
        var self = WOjax.jq.UpdateLink,
            Delegates = WOjax.jq.Delegates,
            $caller = $j(caller),
            $target = $j(target),
            options = $caller.data('wo');

        if (Delegates[options.delegate] !== undefined && Delegates[options.delegate].finished !== undefined) {
            Delegates[options.delegate].finished($caller, $target, self.handleCompletion);
        } else {
            self.handleCompletion($caller, $target);
        }
    },
    handleCompletion: function(_item, _uc) {
        console.log("WOjax update complete");
        // cleanup if necessary
    }
};

// Handle Ajax form submission.
WOjax.jq.Submit = {

    PartialFormSenderIDKey: '_partialSenderID',
    AjaxSubmitButtonNameKey: 'AJAX_SUBMIT_BUTTON_NAME',
    // Scan the page for matching AjaxJQSubmit elements and assign
    // the handleSubmit function as a click event handler.
    register: function () {
        var self = WOjax.jq.Submit;
        $j('.AjaxJQSubmit').livequery('click', function(event) {
            var caller = this,
                $caller = $j(caller);
                
            event.preventDefault(); 
            $caller.type
            self.handleSubmit(caller);
        });
        console.log('Registered Submit');
    },
    // Submit handler. Extract values from clicked element and calculate the id of the element
    // to update. Call the before delegate. The before delegate can choose to call the callback
    // to continue or abort.
    handleSubmit: function (caller, parameters) {
        var self = WOjax.jq.Submit,
            Delegates = WOjax.jq.Delegates,
            $caller = $j(caller),
            options = $caller.data('wo'),
            ucid = '',
            $target = {};

        $caller.data('params', parameters);
        $caller.data('isUpdate', true);
        console.log('options: ' + $j.dump($caller) + ' - ' + $j.dump(options));
        if (options.updateid !== undefined) {
            ucid = '#' + options.updateid;
        } else if (options.replaceid !== undefined) {
            ucid = '#' + options.replaceid;
            $caller.data('isUpdate', false);
        } else {
            // if the caller has neither an updateid or replaceid
            // then lets assume it is updating itself (i.e: a uc with
            // a periodic update)
            ucid = '#' + $caller.attr('id')
        }
        console.log(ucid);
        $target = $j(ucid);
        if (Delegates[options.delegate] !== undefined && Delegates[options.delegate].before !== undefined) {
            console.log('has before delegate');
            // If we have a 'before' delegate then call it with the caller, target, and callback.
            Delegates[options.delegate].before($caller, $target, self.performSubmit);
        } else {
            self.performSubmit($caller, $target);
        }
    },
    // Perform the actual submit. Extract the required paramaters, calculate the action url, append
    // any supplied query params, and update the update container. Call delegate functions on success
    // or failure.
    performSubmit: function (caller, target) {
        var self = WOjax.jq.Submit,
            Delegates = WOjax.jq.Delegates,
            $caller = $j(caller),
            options = $caller.data('wo'), // pull the options out of the data-wo attribute
            $target = $j(target),
            formName = options.form,
            isAsync = true,
            isUpdate = $caller.data('isUpdate'),
            params = $caller.data('params'),
            form = {},
            actionUrl = "",
            data = {};
        
        if (formName !== undefined) {
            form = $j('[name=' + formName + ']');
        } else {
            form = $j($caller.get(0).form);
        }
        console.log("Form: " + $j.dump(form));
        data = form.serialize();
        actionUrl = form.attr('action').replace('/wo/', '/ajax/');
        actionUrl = WOjax.jq.StringUtil.addQueryParameters(actionUrl, self.AjaxSubmitButtonNameKey + '=' + options._asbn);
        
        // is the request asynchronous? Default is true.
        if (options.async !== undefined) {
            isAsync = options.async === 'true';
        }
        // append query params if they exist.
        if (params !== undefined) {
            actionUrl = WOjax.jq.StringUtil.addQueryParameters(url, params); // append any supplied params to the url
        }
        // add query param for update or replace
        if ( isUpdate ) {
            actionUrl = WOjax.jq.StringUtil.addQueryParameters(actionUrl, '_u=' + options.updateid);
        } else {
            actionUrl = WOjax.jq.StringUtil.addQueryParameters(actionUrl, '_r=' + options.replaceid);
        }
        // perform the submit
        console.log('handleSubmit: ' + $j.dump(data) + ' - ' + actionUrl);
        $j.ajax({
            url: actionUrl,
            type: 'POST',
            async: isAsync,
            data: data,
            //beforeSend: function (jqXHR, settings){}, //TODO
            success: function(responseData, textStatus, jqXH) {
                console.log($j.dump(responseData));
                if (isUpdate) {
                    $target.html(responseData);
                } else {
                    $target.replaceWith(responseData);
                }
                if (Delegates[options.delegate] !== undefined && Delegates[options.delegate].success !== undefined) {
                    // if we have a success delegate defined then call it with the caller, target, and callback
                    Delegates[options.delegate].success($caller, $target, self.handleFinish);
                } else {
                    self.handleFinish($caller, $target);
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                options.errorThrown = errorThrown;
                options.textStatus = textStatus;
                if (Delegates[options.delegate] !== undefined && Delegates[options.delegate].error !== undefined) {
                    // if we have a error delegate defined then call it with the caller, target, and callback
                    Delegates[options.delegate].error($caller, $target, self.handleFinish);
                } else {
                    self.handleFinish($caller, $target);
                }
            }
        });
    },
    handleFinish: function(caller, target) {
        var self = WOjax.jq.Submit,
            Delegates = WOjax.jq.Delegates,
            $caller = $j(caller),
            $target = $j(target),
            options = $caller.data('wo');

        if (Delegates[options.delegate] !== undefined && Delegates[options.delegate].finished !== undefined) {
            // if we have finished delegate defined then call it with the caller, target, and callback.
            Delegates[options.delegate].finished($caller, $target, self.handleCompletion);
        } else {
            self.handleCompletion($caller, $target);
        }
    },
    handleCompletion: function(_item, _uc) {
        // finally we are done!
        console.log("WOjax submit complete");
        // cleanup if necessary
    }
}

WOjax.jq.PeriodicUpdate = {

    updaters: {},
    register: function () {
        var self = WOjax.jq.PeriodicUpdate;
        $j('.AjaxJQPeriodicUpdate').livequery(function () { 
            // matched item function
            var item = this,
                $item = $j(item),
                options = $item.data('wo'),
                period = options.period;
                
            console.log($j.dump(options));
            if (period === undefined) {
                period = 5000;
            }
            console.log("period: " + period);
            if (options.stopped === undefined) {
                self.createUpdater(item, period);
            }
        }, 
            function () { // unmatched item function
                var id = $j(this).attr('id');
                self.stop(id);
            });
    },
    createUpdater: function (item, period) {
        console.log("create updater with period: " + period);
        var self = WOjax.jq.PeriodicUpdate,
            $item = $j(item),
            id = $item.attr('id'),
            updater = setInterval( function() {
                WOjax.jq.UpdateLink.handleClick($item)
            } , period);
            
        self.updaters[id] = updater;
    },
    start: function (id) {
        console.log("Periodic start");
        var self = WOjax.jq.PeriodicUpdate,
            item = $j('#' + id),
            period = item.data('wo').period;

        if (period === undefined) {
            period = 5000;
        }
        console.log('start: ' + id + " period: " + period);
        self.createUpdater(item, period);
    },
    stop: function (id) {
        var self = WOjax.jq.PeriodicUpdate,
            updater = self.updaters[id];
        if (updater !== undefined) {
            console.log("Stopping: " + id);
            clearInterval(updater);
            delete self.updaters[id];
        }
    },
    stopAll: function () {
        var self = WOjax.jq.PeriodicUpdate,
            key = "";
        console.log("stop all periodic");
        for (key in self.updaters) {
            self.stop(key);
        }
        // FIXME - implement!
    }
};

WOjax.jq.Observe = {
    register: function () {
        var self = WOjax.jq.Observe;
        $j('.AjaxJQObserve').livequery(function () {
            // Observe added
            var item = $j(this),
                oid = item.data('wo').observeid,
                target = $j('#' + oid);
            
            
            console.log("Adding Observer: " + $j.dump(item) + " Observed: " + $j.dump(target));
        },
        function () {
            console.log($j.dump(this));
            // Observe removed
        });
        console.log('registered Observe')
    }
    
};

// Simple container, really just here to register periodic updates.
WOjax.jq.UpdateContainer = {

    register: function () {
        var self = WOjax.jq.UpdateContainer,
            perUp = WOjax.jq.PeriodicUpdate;
            
        $j('.AjaxJQUpdateContainer').livequery(function() {
            // matched element function
            var item = this,
                $item = $j(item),
                options = $item.data('wo');
                period = options.period;
                
            console.log($j.dump(options));
            console.log("period: " + period);
            if (period !== undefined && options.stopped === undefined) {
                // if we have a period registered and are not stopped,
                // create a periodic updater for this element
                perUp.createUpdater(item, period, true);
            }
        },
        function() {
            // unmatched (removed) element function
            var id = $j(this).attr('id');
            perUp.stop(id);
        });
        console.log("registered UpdateContainer");
    }
};

// UTILITIES
WOjax.jq.StringUtil = {
    // Add query params to a url represented by string
    addQueryParameters: function(string, additionalParameters) {
        if (additionalParameters) {
            return string + (string.match(/\?/) ? '&' : '?') + additionalParameters;
        } else {
            return string;
        }
    }
};

// PAGE INIT
$j(function () {
    WOjax.jq.UpdateLink.register();
    WOjax.jq.Submit.register();
    WOjax.jq.Observe.register();
    WOjax.jq.PeriodicUpdate.register();
    WOjax.jq.UpdateContainer.register();
});